forceload add 27 -7 49 5
fill 27 63 -7 49 63 5 minecraft:deepslate_tiles
fill 27 64 -7 49 67 5 minecraft:air
fill 27 65 -7 49 65 5 computercraft:cable[cable=true]
setblock 28 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 29 66 -5 minecraft:air
setblock 29 66 -5 computercraft:computer_advanced{ComputerId:25573,On:1b}
setblock 32 66 -5 cloudsolutions:crafka_broker
setblock 31 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 35 66 -5 cloudsolutions:kv_storage
setblock 34 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 38 66 -5 cloudsolutions:statsd_bridge
setblock 37 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 41 66 -5 cloudsolutions:tsdb_storage
setblock 40 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 44 66 -5 digitalitems:advanced_digitizer
setblock 43 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 47 66 -5 digitalitems:digitizer
setblock 46 66 -5 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 32 66 -3 peripheralworks:ae2_pattern_pedestal
setblock 31 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 35 66 -3 peripheralworks:display_pedestal
setblock 34 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 38 66 -3 peripheralworks:entity_link
setblock 37 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 41 66 -3 peripheralworks:flexible_reality_anchor
setblock 40 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 44 66 -3 peripheralworks:flexible_statue
setblock 43 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 47 66 -3 peripheralworks:hologram_projector
setblock 46 66 -3 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 32 66 -1 peripheralworks:informative_registry
setblock 31 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 35 66 -1 peripheralworks:item_pedestal
setblock 34 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 38 66 -1 peripheralworks:map_pedestal
setblock 37 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 41 66 -1 peripheralworks:me_network_peripheral
setblock 40 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 44 66 -1 peripheralworks:network_manager
setblock 43 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 47 66 -1 peripheralworks:peripheral_casing
setblock 46 66 -1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 32 66 1 peripheralworks:peripheral_proxy
setblock 31 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 35 66 1 peripheralworks:reality_forger
setblock 34 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 38 66 1 peripheralworks:recipe_registry
setblock 37 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 41 66 1 peripheralworks:remote_observer
setblock 40 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 44 66 1 peripheralworks:statue_workbench
setblock 43 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 47 66 1 peripheralworks:ultimate_sensor
setblock 46 66 1 computercraft:wired_modem_full[modem=true,peripheral=true]
setblock 32 66 3 peripheralworks:universal_scanner
setblock 31 66 3 computercraft:wired_modem_full[modem=true,peripheral=true]
forceload add 57 -8 73 6
fill 57 63 -8 73 63 6 minecraft:deepslate_tiles
fill 57 64 -8 73 67 6 minecraft:air
setblock 58 64 -7 minecraft:air
setblock 58 64 -7 computercraft:turtle_advanced{LeftUpgrade:"cloudsolutions:crafka_broker"}
setblock 60 64 -7 minecraft:air
setblock 60 64 -7 computercraft:turtle_advanced{LeftUpgrade:"cloudsolutions:kv_storage"}
setblock 62 64 -7 minecraft:air
setblock 62 64 -7 computercraft:turtle_advanced{LeftUpgrade:"cloudsolutions:statsd_bridge"}
setblock 64 64 -7 minecraft:air
setblock 64 64 -7 computercraft:turtle_advanced{LeftUpgrade:"digitalitems:advanced_digitizer"}
setblock 66 64 -7 minecraft:air
setblock 66 64 -7 computercraft:turtle_advanced{LeftUpgrade:"digitalitems:digitizer"}
setblock 68 64 -7 minecraft:air
setblock 68 64 -7 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:ae2_wireless_crafting_terminal"}
setblock 70 64 -7 minecraft:air
setblock 70 64 -7 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:ae2_wireless_terminal"}
setblock 72 64 -7 minecraft:air
setblock 72 64 -7 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:hologram_projector"}
setblock 58 64 -5 minecraft:air
setblock 58 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:natures_compass"}
setblock 60 64 -5 minecraft:air
setblock 60 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:netherite_peripheralium_hub"}
setblock 62 64 -5 minecraft:air
setblock 62 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:peripheralium_hub"}
setblock 64 64 -5 minecraft:air
setblock 64 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:transmutation_table"}
setblock 66 64 -5 minecraft:air
setblock 66 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:ultimate_sensor"}
setblock 68 64 -5 minecraft:air
setblock 68 64 -5 computercraft:turtle_advanced{LeftUpgrade:"peripheralworks:universal_scanner"}
setblock 70 64 -5 minecraft:air
setblock 70 64 -5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:automata"}
setblock 72 64 -5 minecraft:air
setblock 72 64 -5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:bow"}
setblock 58 64 -3 minecraft:air
setblock 58 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:brewing_automata"}
setblock 60 64 -3 minecraft:air
setblock 60 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:chatter"}
setblock 62 64 -3 minecraft:air
setblock 62 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:chunk_vial"}
setblock 64 64 -3 minecraft:air
setblock 64 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_brewing_automata"}
setblock 66 64 -3 minecraft:air
setblock 66 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_chest"}
setblock 68 64 -3 minecraft:air
setblock 68 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_enchanting_automata"}
setblock 70 64 -3 minecraft:air
setblock 70 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_end_automata"}
setblock 72 64 -3 minecraft:air
setblock 72 64 -3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_husbandry_automata"}
setblock 58 64 -1 minecraft:air
setblock 58 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_mason_automata"}
setblock 60 64 -1 minecraft:air
setblock 60 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_mercantile_automata"}
setblock 62 64 -1 minecraft:air
setblock 62 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_protective_automata"}
setblock 64 64 -1 minecraft:air
setblock 64 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:creative_smithing_automata"}
setblock 66 64 -1 minecraft:air
setblock 66 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:enchanting_automata"}
setblock 68 64 -1 minecraft:air
setblock 68 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:end_automata"}
setblock 70 64 -1 minecraft:air
setblock 70 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:enormous_automata"}
setblock 72 64 -1 minecraft:air
setblock 72 64 -1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:husbandry_automata"}
setblock 58 64 1 minecraft:air
setblock 58 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:inspection_monocle"}
setblock 60 64 1 minecraft:air
setblock 60 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:lava_bucket"}
setblock 62 64 1 minecraft:air
setblock 62 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:mason_automata"}
setblock 64 64 1 minecraft:air
setblock 64 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:mercantile_automata"}
setblock 66 64 1 minecraft:air
setblock 66 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:mimic"}
setblock 68 64 1 minecraft:air
setblock 68 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:netherite_end_automata"}
setblock 70 64 1 minecraft:air
setblock 70 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:netherite_husbandry_automata"}
setblock 72 64 1 minecraft:air
setblock 72 64 1 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:netherite_protective_automata"}
setblock 58 64 3 minecraft:air
setblock 58 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:piston"}
setblock 60 64 3 minecraft:air
setblock 60 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:protective_automata"}
setblock 62 64 3 minecraft:air
setblock 62 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:smithing_automata"}
setblock 64 64 3 minecraft:air
setblock 64 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:soul_scrapper"}
setblock 66 64 3 minecraft:air
setblock 66 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_brewing_automata"}
setblock 68 64 3 minecraft:air
setblock 68 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_enchanting_automata"}
setblock 70 64 3 minecraft:air
setblock 70 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_end_automata"}
setblock 72 64 3 minecraft:air
setblock 72 64 3 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_husbandry_automata"}
setblock 58 64 5 minecraft:air
setblock 58 64 5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_mason_automata"}
setblock 60 64 5 minecraft:air
setblock 60 64 5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_mercantile_automata"}
setblock 62 64 5 minecraft:air
setblock 62 64 5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_protective_automata"}
setblock 64 64 5 minecraft:air
setblock 64 64 5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:starbound_smithing_automata"}
setblock 66 64 5 minecraft:air
setblock 66 64 5 computercraft:turtle_advanced{LeftUpgrade:"turtlematic:sticky_piston"}
forceload add 57 9 73 15
fill 57 63 9 73 63 15 minecraft:deepslate_tiles
fill 57 64 9 73 67 15 minecraft:air
kill @e[type=minecraft:item_display,tag=mc_test_authored_pocket]
setblock 58 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 58.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_1"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"cloudsolutions:crafka_broker"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 60 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 60.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_2"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"cloudsolutions:kv_storage"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 62 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 62.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_3"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"cloudsolutions:statsd_bridge"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 64 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 64.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_4"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"digitalitems:advanced_digitizer"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 66 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 66.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_5"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"digitalitems:digitizer"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 68 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 68.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_6"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:ae2_wireless_crafting_terminal"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 70 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 70.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_7"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:ae2_wireless_terminal"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 72 64 10 minecraft:lectern[facing=south]
summon minecraft:item_display 72.5 65.15 10.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_8"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:apprentice_magic_tome"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 58 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 58.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_9"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:archmage_magic_tome"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 60 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 60.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_10"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:caster_magic_tome"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 62 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 62.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_11"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:hologram_projector"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 64 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 64.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_12"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:natures_compass"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 66 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 66.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_13"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:netherite_peripheralium_hub"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 68 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 68.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_14"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:novice_magic_tome"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 70 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 70.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_15"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:peripheralium_hub"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 72 64 12 minecraft:lectern[facing=south]
summon minecraft:item_display 72.5 65.15 12.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_16"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:transmutation_table"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 58 64 14 minecraft:lectern[facing=south]
summon minecraft:item_display 58.5 65.15 14.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_17"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:ultimate_sensor"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
setblock 60 64 14 minecraft:lectern[facing=south]
summon minecraft:item_display 60.5 65.15 14.5 {Tags:["mc_test_authored_pocket","mc_test_pocket_18"],Invulnerable:1b,item:{id:"computercraft:pocket_computer_advanced",count:1,components:{"computercraft:pocket_upgrade":{id:"peripheralworks:universal_scanner"}}},item_display:"fixed",transformation:{translation:[0.0f,0.0f,0.0f],scale:[0.8f,0.8f,0.8f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}}
forceload add 27 -8 73 15
say Authored fixture for neoforge-1.21: 25 blocks, 53 turtles, 18 pocket computers.
